import java.util.Scanner;
import javax.swing.JOptionPane;

import java.text.DecimalFormat;
import java.util.Random;
import com.sun.tools.javac.Main;

public class Birthday {

	public static void main(String[] args) {
		
		
		double total = 0;
		String answer, toyAnswer = "";
		Toy aToy = new Toy ();
		JOptionPane.showMessageDialog(null, "Welcome to the Toy Company \nto choose gifts for young children");
		
		do {
		
			String name, ageStr, toy, card, balloon;
		int age, skip = 1;
		
		name = JOptionPane.showInputDialog("Enter the name of the child:");
		ageStr = JOptionPane.showInputDialog("How old is the child?");
		age = Integer.parseInt(ageStr);
		aToy.setAge(age);
		toy = JOptionPane.showInputDialog("Choose a toy: a plushie, blocks, or a book");
		
		while (!toy.equalsIgnoreCase("plushie") && !toy.equalsIgnoreCase("blocks") && !toy.equalsIgnoreCase("book")) {
			
			JOptionPane.showMessageDialog(null, "Invalid choice\nPlease choose again");
			toy = JOptionPane.showInputDialog("Choose a toy: a plushie, blocks, or a book");
		}
		
		while (age < 4 && toy.equalsIgnoreCase("book") && skip == 1) {
			
			toyAnswer = JOptionPane.showInputDialog("This toy is not age-appropriate\n"
					+ "Do you want to buy a different toy? Yes or No");
			
			if (toyAnswer.equalsIgnoreCase("Yes")) {
				
				name = JOptionPane.showInputDialog("Enter the name of the child:");
				ageStr = JOptionPane.showInputDialog("How old is the child?");
				age = Integer.parseInt(ageStr);
				aToy.setAge(age);
				toy = JOptionPane.showInputDialog("Choose a toy: a plushie, blocks, or a book");
			}
			else if (toyAnswer.equalsIgnoreCase("No")) {
				
				skip = 0;
			}
			
		}
		
		if (toy.equalsIgnoreCase("plushie")) {
			
			total += 25.0;
			
		}
		
		else if(toy.equalsIgnoreCase("blocks")) {
			
			total += 20.0;
		}
		
		else if(toy.equalsIgnoreCase("book")) {
			
			total += 15.0;
		}
		
		aToy.setToy(toy);
		//aToy.addCost(total);
		
		
		if (aToy.ageOK() == true) {
			
			JOptionPane.showMessageDialog(null, "Good Choice!");
		}
		
		aToy.setCost(toy);
		card = JOptionPane.showInputDialog("Do you want a card with the gift? Yes or No");
		if (card.equalsIgnoreCase("Yes")) {
			
			aToy.addCard(card);
			//total =+ 2.95;
		}
		balloon = JOptionPane.showInputDialog("Do you want a balloon with the gift? Yes or No");
		if (balloon.equalsIgnoreCase("Yes")) {
			
			aToy.addBalloon(balloon);
			total += 6.0;
		}
		
		JOptionPane.showMessageDialog(null, "The gift for " + name + aToy);
		
		answer = JOptionPane.showInputDialog("Do you want another toy? Yes or No");
		
		if (card.equalsIgnoreCase("Yes")) {
			
			total = total + 2.95;
		}
		}
		while (answer.equalsIgnoreCase("Yes"));
		
		DecimalFormat df = new DecimalFormat("##.##");
		//total = aToy.getCost();
		JOptionPane.showMessageDialog(null, "The total cost of your order is $" + df.format(total));
		JOptionPane.showMessageDialog(null, "Order number is " + (1 + (int)(Math.random() * 100000)) + "\nProgrammer: Julian Morales");
	}
	
}
